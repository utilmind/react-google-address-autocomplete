# react-google-address-autocomplete

Reusable React address autocomplete component powered by Google Places Autocomplete Data API.

## Status

Early implementation. The exported component renders a controlled input, fetches suggestions from a provider, shows a first-pass dropdown, supports mouse selection, supports basic keyboard navigation, can render the dropdown through a portal for dialogs/modals, can customize the input value after a suggestion is selected, hides loading UI by default, and uses browser-autofill-resistant input defaults. The package also includes the initial public types, a tested Google address parser, a browser Google Maps JavaScript loader, and a tested Google Places Autocomplete Data API provider with an explicit free-text geocoding lookup method.

## Design decisions

- Package name: `react-google-address-autocomplete`.
- License: MIT.
- UI model: headless first. The component exposes class names and render props instead of forcing a stylesheet.
- Google integration: browser-side Google Maps JavaScript API key first.
- Server-side proxy provider: deferred.
- Country restriction: unrestricted by default. Pass `countryCodes` when an app wants to restrict results.

## Minimal usage

```tsx
import { useMemo, useState } from 'react'
import { AddressAutocompleteInput, createGooglePlacesAutocompleteProvider } from 'react-google-address-autocomplete'

export function AddressField() {
    const [address, setAddress] = useState('')

    const provider = useMemo(
        () =>
            createGooglePlacesAutocompleteProvider({
                apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
                defaultRequestOptions: {
                    countryCodes: ['US'],
                    language: 'en',
                    region: 'US',
                },
            }),
        [],
    )

    return (
        <AddressAutocompleteInput
            dropdownClassName="addressDropdown"
            inputClassName="addressInput"
            label="Address"
            placeholder="Start typing an address"
            provider={provider}
            value={address}
            onAddressSelect={(selectedAddress) => {
                console.log(selectedAddress)
            }}
            onValueChange={setAddress}
        />
    )
}
```

## Restricting the search area

The component is unrestricted by default. To restrict suggestions to a country or group of countries, pass `countryCodes` directly to `AddressAutocompleteInput`. The Google provider maps this option to the Places Autocomplete Data API region restriction for suggestions.

```tsx
<AddressAutocompleteInput
    countryCodes={['US']}
    label="Address"
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

You can also make a provider default when every input in an app should use the same restriction:

```ts
const provider = createGooglePlacesAutocompleteProvider({
    apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
    defaultRequestOptions: {
        countryCodes: ['US'],
        language: 'en',
        region: 'US',
    },
})
```

Input-level props win over provider defaults, so a reusable provider can still be overridden per field.

## Component props

`AddressAutocompleteInput` is a controlled, headless component. It forwards most regular `<input>` props, except for props that would conflict with its controlled behavior (`value`, `onChange`, `type`, `className`, `children`, and `onSelect`).

| Prop                                 | Type                                               | Default                           | Description                                                                                       |
| ------------------------------------ | -------------------------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------- |
| `value`                              | `string`                                           | required                          | Current input value.                                                                              |
| `onValueChange`                      | `(value: string) => void`                          | required                          | Called when the user types or when a selected suggestion commits a new input value.               |
| `provider`                           | `AddressAutocompleteProvider`                      | `undefined`                       | Suggestion/details provider. Use `createGooglePlacesAutocompleteProvider()` for Google Places.    |
| `onAddressSelect`                    | `(address: SelectedAddress) => void`               | `undefined`                       | Called after the user selects a suggestion and place details are parsed.                          |
| `getSelectedAddressInputValue`       | `(address, suggestion) => string`                  | formatted address                 | Controls what text is committed to the input after selection. Useful for street-only form fields. |
| `previewHighlightedSuggestion`       | `boolean`                                          | `false`                           | Shows the highlighted suggestion in the input during arrow-key navigation without committing it.  |
| `getHighlightedSuggestionInputValue` | `(suggestion) => string`                           | suggestion full text              | Controls preview text when `previewHighlightedSuggestion` is enabled.                             |
| `label`                              | `ReactNode`                                        | `undefined`                       | Optional label rendered above the input and connected with `htmlFor`.                             |
| `minQueryLength`                     | `number`                                           | `1`                               | Minimum trimmed query length before suggestions are fetched.                                      |
| `debounceMs`                         | `number`                                           | `250`                             | Debounce delay before fetching suggestions.                                                       |
| `maxSuggestions`                     | `number`                                           | `5`                               | Maximum suggestions rendered by the component after provider results return.                      |
| `countryCodes`                       | `readonly string[]`                                | unrestricted                      | Restricts suggestions to countries such as `['US']`.                                              |
| `includedPrimaryTypes`               | `readonly string[]`                                | `undefined`                       | Restricts Google predictions to primary place types when the provider supports it.                |
| `language`                           | `string`                                           | provider/default browser behavior | Preferred language for suggestions.                                                               |
| `region`                             | `string`                                           | provider/default browser behavior | Region hint used by Google for result formatting/ranking.                                         |
| `locationBias`                       | `unknown`                                          | `undefined`                       | Biases suggestions toward an area when the provider supports it.                                  |
| `locationRestriction`                | `unknown`                                          | `undefined`                       | Restricts suggestions to an area when the provider supports it.                                   |
| `origin`                             | `{ lat: number; lng: number }`                     | `undefined`                       | Origin point for distance/ranking when the provider supports it.                                  |
| `showLoading`                        | `boolean`                                          | `false`                           | Shows a loading row while suggestions are being fetched.                                          |
| `loadingText`                        | `ReactNode`                                        | `Loading…`                        | Localizable fallback loading content.                                                             |
| `renderLoading`                      | `(state) => ReactNode`                             | `undefined`                       | Fully custom loading row renderer.                                                                |
| `renderEmpty`                        | `(state) => ReactNode`                             | `No addresses found`              | Custom empty-state row renderer.                                                                  |
| `renderError`                        | `(state) => ReactNode`                             | error message                     | Custom error-state row renderer.                                                                  |
| `renderSuggestion`                   | `(props) => ReactNode`                             | built-in minimal markup           | Custom suggestion row renderer.                                                                   |
| `className`                          | `string`                                           | `undefined`                       | Wrapper class name.                                                                               |
| `inputClassName`                     | `string`                                           | `undefined`                       | Input class name.                                                                                 |
| `dropdownClassName`                  | `string`                                           | `undefined`                       | Dropdown/listbox class name.                                                                      |
| `dropdownStyle`                      | `CSSProperties`                                    | `undefined`                       | Inline style for the dropdown. Also merged into portal positioning styles.                        |
| `suggestionClassName`                | `string`                                           | `undefined`                       | Suggestion row class name.                                                                        |
| `highlightedSuggestionClassName`     | `string`                                           | `undefined`                       | Extra class name for the highlighted suggestion row.                                              |
| `statusMessageClassName`             | `string`                                           | `undefined`                       | Class name for loading, empty, and error rows.                                                    |
| `dropdownPortal`                     | `boolean`                                          | `false`                           | Renders the dropdown through a portal, useful inside dialogs and clipped containers.              |
| `dropdownPortalContainer`            | `HTMLElement \| null \| () => HTMLElement \| null` | `document.body`                   | Portal target when `dropdownPortal` is enabled.                                                   |
| `dropdownPortalOffset`               | `number`                                           | `6`                               | Vertical offset between input and portal dropdown.                                                |
| `autoComplete`                       | regular input prop                                 | `one-time-code`                   | Browser-autofill suppression value. Override only when native autofill is desired.                |
| `name`                               | regular input prop                                 | generated neutral name            | Neutral generated name helps suppress browser profile autofill.                                   |

## Provider request options

These component props are passed to `provider.getSuggestions(query, options)`: `countryCodes`, `includedPrimaryTypes`, `language`, `region`, `locationBias`, `locationRestriction`, and `origin`. The built-in Google provider merges them with `defaultRequestOptions` from `createGooglePlacesAutocompleteProvider()`. Component props override provider defaults.

## Selection behavior

`onAddressSelect` fires only when the user selects a suggestion from the dropdown. The component does not geocode free text on blur, Enter, or form submit. This keeps typing predictable: manual edits update only `value` through `onValueChange`; selected suggestions update `value` and call `onAddressSelect`.

If an application wants to verify a manually typed address, call the provider's explicit `lookupAddress()` method from your own button or submit handler.

## Highlighted suggestion preview

By default, arrow-key navigation only changes the highlighted dropdown item. The typed query stays in the input until the user selects a suggestion. To mimic Twitter Typeahead-style behavior where the highlighted item is previewed inside the input during keyboard navigation, enable `previewHighlightedSuggestion`.

```tsx
<AddressAutocompleteInput previewHighlightedSuggestion provider={provider} value={address} onValueChange={setAddress} />
```

Use `getHighlightedSuggestionInputValue` to control the preview text. This is useful when a form should preview only the street line while the dropdown still shows the full address.

```tsx
<AddressAutocompleteInput
    previewHighlightedSuggestion
    getHighlightedSuggestionInputValue={(suggestion) => suggestion.mainText || suggestion.fullText}
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

The preview is visual component state. It does not call `onValueChange` until the user edits the input or selects a suggestion.

## Filling separate form fields

Use `onAddressSelect` to copy structured place data into the rest of your form. By default, the input value becomes the selected place's formatted address. Use `getSelectedAddressInputValue` when your form should keep a different value in the autocomplete field, such as street address only.

```tsx
const [form, setForm] = useState({
    address: '',
    city: '',
    state: '',
    zip: '',
    country: '',
    latitude: '',
    longitude: '',
})

<AddressAutocompleteInput
    getSelectedAddressInputValue={(selectedAddress) =>
        selectedAddress.addressLine1 || selectedAddress.formattedAddress
    }
    label="Address"
    provider={provider}
    value={form.address}
    onAddressSelect={(selectedAddress) => {
        setForm({
            address: selectedAddress.addressLine1,
            city: selectedAddress.city,
            state: selectedAddress.stateCode || selectedAddress.state,
            zip: selectedAddress.postalCodeSuffix
                ? `${selectedAddress.postalCode}-${selectedAddress.postalCodeSuffix}`
                : selectedAddress.postalCode,
            country: selectedAddress.country || selectedAddress.countryCode,
            latitude: selectedAddress.latitude?.toString() ?? '',
            longitude: selectedAddress.longitude?.toString() ?? '',
        })
    }}
    onValueChange={(address) => {
        setForm((current) => ({ ...current, address }))
    }}
/>
```

## Explicit free-text address lookup

The Google provider exposes `lookupAddress(query, options?)` for explicit geocoding of a manually typed address. This is intentionally provider-level API, not automatic component behavior. Use it from a button such as “Lookup” or “Verify address” when the user clearly asks for lookup.

```tsx
const [isLookupPending, setIsLookupPending] = useState(false)
const [lookupError, setLookupError] = useState<string | null>(null)

async function handleLookupClick() {
    if (!provider.lookupAddress || !form.address.trim()) {
        return
    }

    setIsLookupPending(true)
    setLookupError(null)

    try {
        const selectedAddress = await provider.lookupAddress(
            [form.address, form.city, form.state, form.zip, form.country].filter(Boolean).join(', '),
        )

        if (!selectedAddress) {
            setLookupError('No matching address found.')
            return
        }

        setForm({
            address: selectedAddress.addressLine1 || selectedAddress.formattedAddress,
            city: selectedAddress.city,
            state: selectedAddress.stateCode || selectedAddress.state,
            zip: selectedAddress.postalCodeSuffix
                ? `${selectedAddress.postalCode}-${selectedAddress.postalCodeSuffix}`
                : selectedAddress.postalCode,
            country: selectedAddress.country || selectedAddress.countryCode,
            latitude: selectedAddress.latitude?.toString() ?? '',
            longitude: selectedAddress.longitude?.toString() ?? '',
        })
    } finally {
        setIsLookupPending(false)
    }
}
```

The demo app shows this pattern with an input-adjacent button and a spinner.

## Loading state

The component tracks loading internally while suggestions are being fetched, but it does not show a loading row by default. This keeps the dropdown quiet for fast address searches. Enable `showLoading` when your UI should show an interim loading message. Use `loadingText` for simple localization, or `renderLoading` for fully custom markup such as a spinner.

```tsx
<AddressAutocompleteInput
    showLoading
    loadingText="Loading..."
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

```tsx
<AddressAutocompleteInput
    showLoading
    renderLoading={() => <span className="loadingRow">Loading addresses...</span>}
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

## Portal dropdowns

By default, the dropdown is rendered inline under the input. For dialogs, modals, and other containers with `overflow: hidden`, enable portal rendering:

```tsx
<AddressAutocompleteInput
    dropdownClassName="addressDropdown"
    dropdownPortal
    dropdownStyle={{ zIndex: 1000 }}
    inputClassName="addressInput"
    label="Address"
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

When `dropdownPortal` is enabled, the dropdown is rendered into `document.body` by default and receives fixed-position inline styles that match the input's viewport position and width. Use `dropdownPortalContainer` to provide a custom container and `dropdownPortalOffset` to tune the vertical offset.

## Browser autofill

Chrome and other browsers can still show saved address/profile autofill UI over custom autocomplete widgets, even when `autocomplete="off"` is present. To reduce that interference, `AddressAutocompleteInput` defaults to `autoComplete="one-time-code"` and assigns a neutral generated `name` when the consumer does not pass one.

You can still override both values when your application needs native browser autofill or a stable form field name:

```tsx
<AddressAutocompleteInput
    autoComplete="street-address"
    name="shipping-address"
    provider={provider}
    value={address}
    onValueChange={setAddress}
/>
```

For address-search use cases, keep the defaults unless you intentionally want the browser's saved-profile dropdown. This remains best-effort suppression because browsers can still use heuristics that ignore application preferences.

## Google provider

```ts
import { createGooglePlacesAutocompleteProvider } from 'react-google-address-autocomplete'

const provider = createGooglePlacesAutocompleteProvider({
    apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
    defaultRequestOptions: {
        countryCodes: ['US'],
        language: 'en',
        region: 'US',
    },
})

const suggestions = await provider.getSuggestions('13133 34th Street North')
const selectedAddress = await provider.selectSuggestion(suggestions[0])
const lookedUpAddress = await provider.lookupAddress?.('13133 34th Street North, Clearwater, FL')
```

The provider loads the Google Maps JavaScript API in the browser, imports the `places` library for dropdown suggestions, imports the `geocoding` library for explicit `lookupAddress()` calls, calls `AutocompleteSuggestion.fetchAutocompleteSuggestions()`, and fetches selected place details through the original `PlacePrediction`. It creates one Google `AutocompleteSessionToken` per autocomplete session and resets that token after a successful selection.

## Demo app

The demo app includes a dark theme, themed dropdown scrollbars, a local Lucide-style MapPin SVG suggestion icon, and a Lucide-style loading spinner in the first autocomplete example. These styles are intentionally demo-owned; the package itself remains headless and does not ship required CSS or icon dependencies.

This repository uses pnpm workspaces. Run the demo from the repository root:

```bash
pnpm install
cp apps/demo/.env.example apps/demo/.env
pnpm dev
```

Then add `VITE_GOOGLE_MAPS_API_KEY` to `apps/demo/.env`. The key should be a browser-restricted Google Maps JavaScript API key with Places enabled. To target the demo directly, use `pnpm --filter address-autocomplete-demo dev`.

## Selected address shape

```ts
export interface SelectedAddress {
    placeId: string
    formattedAddress: string
    addressLine1: string
    addressLine2: string
    city: string
    state: string
    stateCode: string
    postalCode: string
    postalCodeSuffix: string
    country: string
    countryCode: string
    latitude: number | null
    longitude: number | null
    rawPlace?: unknown
}
```

## Parser utility

The package exports `parseGooglePlaceAddress()` so address-component parsing can be tested and reused independently from React rendering.

```ts
import { parseGooglePlaceAddress } from 'react-google-address-autocomplete'

const selectedAddress = parseGooglePlaceAddress(place)
```

The parser accepts both newer Google Maps JavaScript Place-like fields, such as `formattedAddress` and `addressComponents`, and legacy-shaped fields, such as `formatted_address` and `address_components`. This keeps unit tests simple and makes future provider implementation less brittle.
